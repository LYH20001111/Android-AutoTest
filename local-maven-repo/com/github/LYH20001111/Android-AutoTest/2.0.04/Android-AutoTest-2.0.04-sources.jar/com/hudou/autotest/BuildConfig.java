/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.hudou.autotest;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.hudou.autotest";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String AUTHOR = "Liu YiHong";
  // Field from default config.
  public static final String STRUCTURE_VERSION = "2.0.04";
}
