package com.hudou.autotest.fragment;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.StringRes;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.hudou.autotest.R;
import com.hudou.autotest.adapter.TableAdapter;
import com.hudou.autotest.constant.TableItem;
import com.hudou.autotest.report.excel.ReportOutput;
import com.hudou.autotest.ui.dialog.listener.CustomDialogListener;
import com.hudou.autotest.ui.dialog.listener.EditDialogListener;
import com.hudou.autotest.ui.dialog.listener.ListActionDialogListener;
import com.hudou.autotest.ui.dialog.listener.MultiChoiceDialogListener;
import com.hudou.autotest.ui.dialog.listener.NewCustomDialogListener;
import com.hudou.autotest.ui.dialog.listener.NotifyDialogListener;
import com.hudou.autotest.ui.dialog.listener.NotifyOptionDialogListener;
import com.hudou.autotest.ui.dialog.listener.SingleChoiceDialogListener;
import com.hudou.autotest.util.FileUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

class Dialog {
    private static int yourChoice = 0;
    private static ArrayList<Integer> choiceList = new ArrayList<>();
    private static android.app.Dialog notifyDialog, editTextDialog, singleDialog, customSingleDialog, multiDialog;


    public static void notifyDialog(final Context context, final String title) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final AtomicBoolean dialogShown = new AtomicBoolean(false);

        new Thread(() -> {
            Looper.prepare();
            // 创建自定义标题视图
            LayoutInflater inflater = LayoutInflater.from(context);
            View customTitleView = inflater.inflate(R.layout.auto_test_custom_dialog_title, null);
            TextView titleTextView = customTitleView.findViewById(R.id.dialog_title);
            titleTextView.setText(title);

            notifyDialog = new AlertDialog.Builder(context)
                    .setCustomTitle(customTitleView)
                    .setPositiveButton(R.string.sure, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(() -> {
                            // 在主线程中执行需要同步的操作
                            // 例如，通知主线程对话框已经关闭
                        });
                    })
                    .setCancelable(false)
                    .create();
            notifyDialog.show();
            dialogShown.set(true);
            Looper.loop();
        }).start();

        // 等待对话框显示
        while (!dialogShown.get()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 创建提示对话框
     *
     * @param context
     * @param title   对话框标题
     */
    public static void notifyDialog(final Context context, final String title, final NotifyDialogListener callback) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final AtomicBoolean dialogShown = new AtomicBoolean(false);

        new Thread(() -> {
            Looper.prepare();
            notifyDialog = new AlertDialog.Builder(context)
                    .setTitle(title)
                    .setPositiveButton(R.string.sure, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(() -> {
                            // 在主线程中执行回调
                            callback.onAction();
                        });
                    })
                    .setCancelable(false)
                    .create();
            notifyDialog.show();
            dialogShown.set(true);
            Looper.loop();
        }).start();

        // 等待对话框显示
        while (!dialogShown.get()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void notifyOptionsDialog(final Context context, final CharSequence title, final NotifyOptionDialogListener callback) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final AtomicBoolean dialogShown = new AtomicBoolean(false);

        new Thread(() -> {
            Looper.prepare();
            notifyDialog = new AlertDialog.Builder(context)
                    .setTitle(title)
                    .setIcon(R.drawable.auto_test_warning)
                    .setPositiveButton(R.string.sure, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(callback::onPositive);
                    })
                    .setNegativeButton(R.string.cancel, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(callback::onNegative);
                    })
                    .setCancelable(false)
                    .create();
            notifyDialog.show();
            dialogShown.set(true);
            Looper.loop();
        }).start();

        // 等待对话框显示
        while (!dialogShown.get()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void editDialog(final Context context, @StringRes int hint, final boolean onlyNumber, final EditDialogListener callback) {
        editDialog(context, context.getString(hint, ""), onlyNumber, callback);
    }

    public static void editDialog(final Context context, final String hint, final boolean onlyNumber, final EditDialogListener callback) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final AtomicBoolean dialogShown = new AtomicBoolean(false);

        new Thread(() -> {
            Looper.prepare();
            // 创建自定义布局
            View dialogView = LayoutInflater.from(context).inflate(R.layout.auto_test_dialog_edit_text, null);
            EditText editText = dialogView.findViewById(R.id.edit_text);

            // 设置输入类型
            if (onlyNumber) {
                editText.setInputType(InputType.TYPE_CLASS_NUMBER);
            }
            editText.setHint(hint);
            editTextDialog = new AlertDialog.Builder(context)
                    .setView(dialogView)
                    .setPositiveButton(R.string.sure, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            handler.post(() -> {
                                // 在主线程中执行回调
                                callback.onResult(editText.getText().toString());
                            });
                        }
                    })
                    .setCancelable(false)
                    .create();
            editTextDialog.show();
            dialogShown.set(true);
            Looper.loop();
        }).start();

        // 等待对话框显示
        while (!dialogShown.get()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 创建单选对话框
     *
     * @param context
     * @param titleId  对话框标题
     * @param items    选项
     * @param callback 选择回调
     */
    public static void singleChoiceDialog(final Context context, @StringRes int titleId, final String[] items, final SingleChoiceDialogListener callback) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final AtomicBoolean dialogShown = new AtomicBoolean(false);

        new Thread(() -> {
            if (items == null || items.length < 1) {
                return;
            }
            yourChoice = 0;
            Looper.prepare();
            singleDialog = new AlertDialog.Builder(context)
                    .setTitle(titleId)
                    .setSingleChoiceItems(items, 0, (dialog, which) -> yourChoice = which)
                    .setPositiveButton(R.string.sure, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(() -> callback.onResult(yourChoice));
                    })
                    .setNegativeButton(R.string.cancel, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(() -> callback.onResult(-1));
                    })
                    .setCancelable(false)
                    .create();
            singleDialog.show();
            dialogShown.set(true);
            Looper.loop();
        }).start();

        // 等待对话框显示
        while (!dialogShown.get()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 创建多选框
     *
     * @param context
     * @param titleId  对话框标题
     * @param items    选项
     * @param callback
     */
    public static void multiChoiceDialog(final Context context, @StringRes int titleId, final String[] items, final MultiChoiceDialogListener callback) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final AtomicBoolean dialogShown = new AtomicBoolean(false);

        new Thread(() -> {
            if (items == null || items.length < 1) {
                return;
            }
            Looper.prepare();
            choiceList = new ArrayList<>();
            final boolean[] choiceItems = new boolean[items.length];
            multiDialog = new AlertDialog.Builder(context)
                    .setTitle(titleId)
                    .setMultiChoiceItems(items, null, (dialog, which, isChecked) -> {
                        choiceItems[which] = isChecked;
                    })
                    .setPositiveButton(R.string.sure, (dialog, which) -> {
                        dialog.dismiss();
                        for (int i = 0; i < choiceItems.length; i++) {
                            if (choiceItems[i]) {
                                choiceList.add(i);
                            }
                        }
                        handler.post(() -> {
                            try {
                                callback.onResult(choiceList);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });
                    })
                    .setNegativeButton(R.string.cancel, (dialog, which) -> {
                        dialog.dismiss();
                    })
                    .setCancelable(false)
                    .create();
            multiDialog.show();
            dialogShown.set(true);
            Looper.loop();
        }).start();

        // 等待对话框显示
        while (!dialogShown.get()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 创建自定义单选对话框
     *
     * @param context
     * @param titleId  对话框标题
     * @param items    单选选项
     * @param layoutId 布局id
     * @param callback 选择回调
     */
    public static void customDialog(final Context context, @StringRes int titleId, final String[] items, final int layoutId, final CustomDialogListener callback) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final AtomicBoolean dialogShown = new AtomicBoolean(false);

        new Thread(() -> {
            yourChoice = 0;
            Looper.prepare();
            AlertDialog.Builder singleChoiceDialog = new AlertDialog.Builder(context);
            if (items != null && items.length > 1) {
                singleChoiceDialog.setSingleChoiceItems(items, 0, (dialog, which) -> yourChoice = which);
            }
            final View view = LayoutInflater.from(context).inflate(layoutId, null);
            customSingleDialog = singleChoiceDialog
                    .setTitle(titleId)
                    .setView(view)
                    .setPositiveButton(R.string.sure, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(() -> {
                            try {
                                callback.onResult(yourChoice, view);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });
                    })
                    .setNegativeButton(R.string.cancel, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(() -> {
                            try {
                                callback.onResult(-1, view);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });
                    })
                    .setCancelable(false)
                    .create();
            customSingleDialog.show();
            dialogShown.set(true);
            Looper.loop();
        }).start();

        // 等待对话框显示
        while (!dialogShown.get()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void customDialog(final Context context, final int title, final String[] items, final int layoutId, final NewCustomDialogListener callback) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final AtomicBoolean dialogShown = new AtomicBoolean(false);

        new Thread(() -> {
            yourChoice = 0;
            Looper.prepare();
            AlertDialog.Builder singleChoiceDialog = new AlertDialog.Builder(context);
            final View view = LayoutInflater.from(context).inflate(layoutId, null);
            handler.post(() -> callback.onInit(view)); // 在主线程中调用 onInit
            if (items != null && items.length > 1) {
                singleChoiceDialog.setSingleChoiceItems(items, 0, (dialog, which) -> yourChoice = which);
            }
            customSingleDialog = singleChoiceDialog
                    .setTitle(title)
                    .setView(view)
                    .setPositiveButton(R.string.sure, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(() -> {
                            try {
                                callback.onResult(yourChoice, view);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });
                    })
                    .setNegativeButton(R.string.cancel, (dialog, which) -> {
                        dialog.dismiss();
                    })
                    .setCancelable(false)
                    .create();
            customSingleDialog.show();
            dialogShown.set(true);
            Looper.loop();
        }).start();

        // 等待对话框显示
        while (!dialogShown.get()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private static androidx.appcompat.app.AlertDialog loadingAlertDialog;

    private static void showLoadingDialog(Activity activity, String loadingMessage) {
        if (loadingAlertDialog != null && loadingAlertDialog.isShowing()) {
            return; // 如果对话框已经显示，则不重复创建
        }
        loadingAlertDialog = new androidx.appcompat.app.AlertDialog.Builder(activity).create();
        LayoutInflater inflater = activity.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.auto_test_loading_view, null);
        TextView textView = dialogView.findViewById(R.id.tv_content);
        textView.setText(loadingMessage);
        loadingAlertDialog.setView(dialogView);
        loadingAlertDialog.setCanceledOnTouchOutside(false); // 设置点击外部区域是否取消对话框
        loadingAlertDialog.setCancelable(false);
        loadingAlertDialog.show();
    }

    /**
     * 创建列表 + 操作按钮对话框（取消/删除/修改）
     *
     * @param context
     * @param titleId  对话框标题
     * @param items    选项
     * @param callback 回调（selectedIndex：选中项索引 0 开始，取消为 -1；actionIndex：0=取消、1=删除、2=修改）
     */
    public static void listActionDialog(final Context context, @StringRes int titleId, final String[] items, final ListActionDialogListener callback) {
        final Handler handler = new Handler(Looper.getMainLooper());
        final AtomicBoolean dialogShown = new AtomicBoolean(false);

        new Thread(() -> {
            if (items == null || items.length < 1) {
                return;
            }
            yourChoice = 0;
            Looper.prepare();
            singleDialog = new AlertDialog.Builder(context)
                    .setTitle(titleId)
                    .setSingleChoiceItems(items, 0, (dialog, which) -> yourChoice = which)
                    .setNeutralButton(R.string.cancel, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(() -> callback.onResult(-1, 0));
                    })
                    .setNegativeButton(R.string.execution_operation_delete, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(() -> callback.onResult(yourChoice, 1));
                    })
                    .setPositiveButton(R.string.execution_operation_modify, (dialog, which) -> {
                        dialog.dismiss();
                        handler.post(() -> callback.onResult(yourChoice, 2));
                    })
                    .setCancelable(false)
                    .create();
            singleDialog.show();
            dialogShown.set(true);
            Looper.loop();
        }).start();

        // 等待对话框显示
        while (!dialogShown.get()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void loadingFilesDialog(Activity activity, List<String> fileDirList, String loadedDirectory) {
        showLoadingDialog(activity, "Loading assets files ......");
        new Thread(() -> {
            try {
                for (int i = 0; i < fileDirList.size(); i++) {
                    FileUtil.loadAssetsFolder(activity, fileDirList.get(i), loadedDirectory);
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            // 回到主线程更新UI
            boolean finalResult = true;
            activity.runOnUiThread(() -> {
                if (loadingAlertDialog != null && loadingAlertDialog.isShowing()) {
                    loadingAlertDialog.dismiss();
                }
                if (finalResult) {
                    Toast.makeText(activity, "Success", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity, "Failed", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    public static void outputDialog(Activity activity, String prefix, int index) {
        showLoadingDialog(activity, "Outputting Report......");
        new Thread(() -> {
            boolean result;
            result = new ReportOutput().outputExcel(prefix, index);
            boolean finalResult = result;
            activity.runOnUiThread(() -> {
                if (loadingAlertDialog != null && loadingAlertDialog.isShowing()) {
                    loadingAlertDialog.dismiss();
                }
                if (finalResult) {
                    Toast.makeText(activity, "Success", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity, "Failed", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    public static void createTableDialog(Context context, String title, List<TableItem> items) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View view = LayoutInflater.from(context).inflate(R.layout.auto_test_dialog_table_layout, null);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);

        TableAdapter adapter = new TableAdapter(items);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.setAdapter(adapter);

        builder.setTitle(title)
                .setView(view)
                .setPositiveButton(R.string.dialog_confirm, null)
                .setCancelable(false);

        AlertDialog dialog = builder.create();
        dialog.show();

        // 获取标题视图并设置居中(测试发现没有效果)
//        TextView titleView = dialog.findViewById(android.R.id.title);
//        if (titleView != null) {
//            titleView.setGravity(Gravity.CENTER);
//        }
    }


}
