package com.hudou.autotest.report.excel;

import android.content.Context;
import android.os.Environment;

import com.hudou.autotest.R;
import com.hudou.autotest.annotation.TestCase;
import com.hudou.autotest.annotation.TestItem;
import com.hudou.autotest.base.activity.AutoTestMainActivity;
import com.hudou.autotest.constant.ResultData;
import com.hudou.autotest.constant.ResultItem;
import com.hudou.autotest.fragment.AutoTestSettingFragment;
import com.hudou.autotest.util.ATLoggerUtils;
import static com.hudou.autotest.constant.TestResult.*;

import com.hudou.autotest.util.DeviceUtils;
import com.hudou.autotest.util.ReflectionUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Pattern;

import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.Alignment;
import jxl.format.Colour;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

public class ExcelUtils {
    private static WritableCellFormat fileNameFormat = null;
    private static WritableCellFormat titleFormat = null;
    private static WritableCellFormat contentFormat = null;
    private static WritableCellFormat failResultFormat = null;
    private static WritableCellFormat detailFormat = null;

    public static void initExcel(String fileName, LinkedHashMap<String, String[]> sheetMap) {
        initFormat();
        WritableWorkbook workbook = null;
        try {
            File file = new File(fileName);
            if (!file.exists()) {
                file.createNewFile();
            }
            workbook = Workbook.createWorkbook(file);

            int index = 0;
            for (String key : sheetMap.keySet()) {
                WritableSheet sheet = workbook.createSheet(key, index);
                for (int j = 0; j < sheetMap.get(key).length; j++) {
                    sheet.addCell(new Label(j, 0, sheetMap.get(key)[j], titleFormat));
                }
                sheet.setRowView(0, 340);
                index++;
            }
            workbook.write();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (workbook != null) {
                try {
                    workbook.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Set parameters such as format font
     */
    private static void initFormat() {
        try {
            WritableFont fileNameFont = new WritableFont(WritableFont.ARIAL, 14, WritableFont.BOLD);
            fileNameFormat = new WritableCellFormat(fileNameFont);
            fileNameFormat.setAlignment(Alignment.CENTRE);
            fileNameFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            fileNameFormat.setBackground(Colour.VERY_LIGHT_YELLOW);

            WritableFont titleFont = new WritableFont(WritableFont.ARIAL, 10, WritableFont.BOLD);
            titleFormat = new WritableCellFormat(titleFont);
            titleFormat.setAlignment(Alignment.CENTRE);
            titleFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN);
            titleFormat.setBackground(Colour.GRAY_25);

            WritableFont contentFont = new WritableFont(WritableFont.ARIAL, 10);
            contentFormat = new WritableCellFormat(contentFont);
            contentFormat.setAlignment(Alignment.CENTRE);//居中
            contentFormat.setVerticalAlignment(VerticalAlignment.CENTRE);
            contentFormat.setWrap(true);//自动换行
            contentFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN); //边框

            failResultFormat = new WritableCellFormat(contentFont);
            failResultFormat.setAlignment(Alignment.CENTRE);//居中
            failResultFormat.setVerticalAlignment(VerticalAlignment.CENTRE);
            failResultFormat.setWrap(true);//自动换行
            failResultFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN); //边框
            failResultFormat.setBackground(Colour.RED);//适用于案例失败

            detailFormat = new WritableCellFormat(contentFont);
            detailFormat.setAlignment(Alignment.LEFT);//居左
            detailFormat.setVerticalAlignment(VerticalAlignment.CENTRE);
            detailFormat.setWrap(true);//自动换行
            detailFormat.setBorder(jxl.format.Border.ALL, jxl.format.BorderLineStyle.THIN); //边框
        } catch (WriteException e) {
            e.printStackTrace();
        }
    }

    private static int getCaseTotalCount(Class<?> clz) {
        return (int) Arrays.stream(clz.getDeclaredMethods())
                .filter(m -> m.isAnnotationPresent(TestCase.class))
                .count();
    }

    @SuppressWarnings("unchecked")
    public static <T> boolean writeDataToExcel(List<ResultItem> resultItemList, String fileName, Context context) {
        if (resultItemList != null) {
            WritableWorkbook writebook = null;
            InputStream in = null;
            try {
                WorkbookSettings setEncode = new WorkbookSettings();
                setEncode.setEncoding("UTF-8");
                //setEncode.setEncoding("ISO-8859-1");
                writebook = Workbook.createWorkbook(new File(fileName), Workbook.getWorkbook(new FileInputStream(new File(fileName)), setEncode));


                WritableSheet summarySheet = writebook.getSheet(0);
                summarySheet.setColumnView(0, 30); //设置列宽
                summarySheet.setColumnView(1, 20);
                summarySheet.setColumnView(2, 20);
                summarySheet.setColumnView(3, 20);
                summarySheet.setColumnView(4, 20);
                summarySheet.setColumnView(5, 20);
                summarySheet.setColumnView(6, 40);
                summarySheet.setColumnView(7, 20);
                summarySheet.setColumnView(8, 20);
                summarySheet.setColumnView(9, 20);


                WritableSheet detailSheet = writebook.getSheet(1);
                detailSheet.setColumnView(0, 25); //设置列宽
                detailSheet.setColumnView(1, 25);
                detailSheet.setColumnView(2, 50);
                detailSheet.setColumnView(3, 50);
                detailSheet.setColumnView(4, 50);
                detailSheet.setColumnView(5, 50);

                int row = 1;
                long totalSize = 0;
                long executedSize = 0;
                long totalTime = 0;
                Class<?>[] allClasses = AutoTestMainActivity.allTestItemClasses;
                if (allClasses != null) {
                    for (Class<?> clz : allClasses) {
                        String name = ReflectionUtils.getAnnotationValue(clz, TestItem.class, TestItem.Members.name);
                        TestItem testItemAnnotation = clz.getAnnotation(TestItem.class);
                        boolean unsupported = testItemAnnotation != null && DeviceUtils.isDeviceUnsupported(testItemAnnotation.unsupportedDevice());
                        int caseTotal = getCaseTotalCount(clz);
                        if (unsupported) {
                            summarySheet.addCell(new Label(0, row, name, contentFormat));
                            summarySheet.addCell(new Label(1, row, String.valueOf(caseTotal), contentFormat));
                            summarySheet.addCell(new Label(2, row, context.getString(R.string.unsupported_message), contentFormat));
                            summarySheet.addCell(new Label(3, row, context.getString(R.string.unsupported_message), contentFormat));
                            summarySheet.addCell(new Label(4, row, context.getString(R.string.unsupported_message), contentFormat));
                            summarySheet.addCell(new Label(5, row, context.getString(R.string.unsupported_message), contentFormat));
                            summarySheet.addCell(new Label(6, row, context.getString(R.string.zero_percent_message), contentFormat));
                            summarySheet.addCell(new Label(7, row, context.getString(R.string.dash_message), contentFormat));
                            summarySheet.addCell(new Label(8, row, context.getString(R.string.dash_message), contentFormat));
                            summarySheet.addCell(new Label(9, row, context.getString(R.string.zero_second_message), contentFormat));
                            totalSize += caseTotal;
                        } else {
                            ResultItem found = null;
                            for (ResultItem ri : resultItemList) {
                                if (ri.getClz().equals(clz)) {
                                    found = ri;
                                    break;
                                }
                            }
                            if (found != null) {
                                summarySheet.addCell(new Label(0, row, name, contentFormat));
                                summarySheet.addCell(new Label(1, row, String.valueOf(caseTotal), contentFormat));
                                summarySheet.addCell(new Label(2, row, String.valueOf(found.getResultDataList().size()), contentFormat));
                                summarySheet.addCell(new Label(3, row, String.valueOf(countPass(found.getResultDataList())), contentFormat));
                                summarySheet.addCell(new Label(4, row, String.valueOf(countAbandon(found.getResultDataList())), contentFormat));
                                summarySheet.addCell(new Label(5, row, String.valueOf(countFail(found.getResultDataList())), contentFormat));
                                summarySheet.addCell(new Label(6, row, percentageCalculator(countPass(found.getResultDataList()) + countAbandon(found.getResultDataList()), found.getResultDataList().size()), contentFormat));
                                summarySheet.addCell(new Label(7, row, String.valueOf(found.getStartTime()), contentFormat));
                                summarySheet.addCell(new Label(8, row, String.valueOf(found.getEndTime()), contentFormat));
                                summarySheet.addCell(new Label(9, row, String.valueOf(ExcelUtils.timeDifference(found.getStartTime(), found.getEndTime()) + " s"), contentFormat));
                                executedSize += found.getResultDataList().size();
                                totalTime += ExcelUtils.timeDifference(found.getStartTime(), found.getEndTime());
                            } else {
                                summarySheet.addCell(new Label(0, row, name, contentFormat));
                                summarySheet.addCell(new Label(1, row, String.valueOf(caseTotal), contentFormat));
                                summarySheet.addCell(new Label(2, row, context.getString(R.string.zero_message), contentFormat));
                                summarySheet.addCell(new Label(3, row, context.getString(R.string.zero_message), contentFormat));
                                summarySheet.addCell(new Label(4, row, context.getString(R.string.zero_message), contentFormat));
                                summarySheet.addCell(new Label(5, row, context.getString(R.string.zero_message), contentFormat));
                                summarySheet.addCell(new Label(6, row, context.getString(R.string.zero_percent_message), contentFormat));
                                summarySheet.addCell(new Label(7, row, context.getString(R.string.dash_message), contentFormat));
                                summarySheet.addCell(new Label(8, row, context.getString(R.string.dash_message), contentFormat));
                                summarySheet.addCell(new Label(9, row, context.getString(R.string.zero_second_message), contentFormat));
                            }
                            totalSize += caseTotal;
                        }
                        row++;
                    }
                } else {
                    for (ResultItem item : resultItemList) {
                        int caseTotal = getCaseTotalCount(item.getClz());
                        summarySheet.addCell(new Label(0, row, ReflectionUtils.getAnnotationValue(item.getClz(), TestItem.class, TestItem.Members.name), contentFormat));
                        summarySheet.addCell(new Label(1, row, String.valueOf(caseTotal), contentFormat));
                        summarySheet.addCell(new Label(2, row, String.valueOf(item.getResultDataList().size()), contentFormat));
                        summarySheet.addCell(new Label(3, row, String.valueOf(countPass(item.getResultDataList())), contentFormat));
                        summarySheet.addCell(new Label(4, row, String.valueOf(countAbandon(item.getResultDataList())), contentFormat));
                        summarySheet.addCell(new Label(5, row, String.valueOf(countFail(item.getResultDataList())), contentFormat));
                        summarySheet.addCell(new Label(6, row, percentageCalculator(countPass(item.getResultDataList()) + countAbandon(item.getResultDataList()), item.getResultDataList().size()), contentFormat));
                        summarySheet.addCell(new Label(7, row, String.valueOf(item.getStartTime()), contentFormat));
                        summarySheet.addCell(new Label(8, row, String.valueOf(item.getEndTime()), contentFormat));
                        summarySheet.addCell(new Label(9, row, String.valueOf(ExcelUtils.timeDifference(item.getStartTime(), item.getEndTime()) + " s"), contentFormat));
                        totalSize += caseTotal;
                        executedSize += item.getResultDataList().size();
                        totalTime += ExcelUtils.timeDifference(item.getStartTime(), item.getEndTime());
                        row++;
                    }
                }
                summarySheet.addCell(new Label(1, row + 1, context.getString(R.string.total_number, String.valueOf(totalSize)), contentFormat));
                summarySheet.addCell(new Label(2, row + 1, context.getString(R.string.executed_total_number, String.valueOf(executedSize)), contentFormat));
                summarySheet.addCell(new Label(9, row + 1, context.getString(R.string.total_time, formatTotalTime(totalTime)), contentFormat));

                int r = 1;
                for (ResultItem item : resultItemList) {
                    // 对每个 ResultItem 的 resultDataList 按 id 排序
                    item.getResultDataList().sort((o1, o2) -> o1.getId().compareTo(o2.getId()));
                    for (int i = 0; i < item.getResultDataList().size(); i++) {
                        detailSheet.addCell(new Label(0, r, ReflectionUtils.getAnnotationValue(item.getClz(), TestItem.class, TestItem.Members.name), contentFormat));
                        detailSheet.addCell(new Label(1, r, item.getResultDataList().get(i).getId(), contentFormat));
                        if (RESULT_PASS.equals(item.getResultDataList().get(i).getResult())) {
                            detailSheet.addCell(new Label(2, r, AutoTestSettingFragment.isEnglishReport() ? "PASS" : item.getResultDataList().get(i).getResult(), contentFormat));
                        } else if (RESULT_ABANDON.equals(item.getResultDataList().get(i).getResult()) || RESULT_DEVICE_UNSUPPORTED.equals(item.getResultDataList().get(i).getResult())) {
                            detailSheet.addCell(new Label(2, r, AutoTestSettingFragment.isEnglishReport() ? "NA" : item.getResultDataList().get(i).getResult(), contentFormat));
                        } else {
                            detailSheet.addCell(new Label(2, r, AutoTestSettingFragment.isEnglishReport() ? "FAIL" : item.getResultDataList().get(i).getResult(), failResultFormat));
                        }
                        detailSheet.addCell(new Label(3, r, item.getResultDataList().get(i).getTestCaseName(), contentFormat));
                        detailSheet.addCell(new Label(4, r, item.getResultDataList().get(i).getEnglishDescription(), contentFormat));
                        String detail = item.getResultDataList().get(i).getDetail();
                        int maxLength = 32767;
                        if (detail.length() > maxLength) {
                            detail = detail.substring(0, maxLength - 767) + "...(truncated)"; // 保留提示空间
                        }
                        detailSheet.addCell(new Label(5, r, detail, detailFormat));
//                        detailSheet.addCell(new Label(5, r, item.getResultDataList().get(i).getDetail(), detailFormat));
                        r++;
                    }
                }

                writebook.write();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (writebook != null) {
                    try {
                        writebook.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (in != null) {
                    try {
                        in.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return true;
    }

    /**
     * Determine whether sdcard exist or not
     *
     * @return true: exist; false: not exist.
     */
    private static boolean existSDCard() {
        return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
    }

    // 获取存储根目录
    private static String getRootStorage() {
        if (existSDCard()) {
            return Environment.getExternalStorageDirectory().getAbsolutePath();
        } else {
            return null;
        }
    }

    /**
     * Convert timestamp to time
     *
     * @param s timestamp
     * @return the format data of you want
     */
    public static String stampToDate(String s) {
        String res;
        Pattern pattern = Pattern.compile("[0-9]*");
        if (!pattern.matcher(s).matches()) return "";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        long lt = new Long(s);
        Date date = new Date(lt);
        res = simpleDateFormat.format(date);
        return res;
    }

    public static String testCaseDate(String s) {
        String res;
        Pattern pattern = Pattern.compile("[0-9]*");
        if (!pattern.matcher(s).matches()) return "";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
        long lt = new Long(s);
        Date date = new Date(lt);
        res = simpleDateFormat.format(date);
        return res;
    }

    public static long timeDifference(String startTime, String endTime) {
        long diffInSeconds = 0;
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        try {
            Date start = sdf.parse(startTime);
            Date end = sdf.parse(endTime);

            long diffInMillis = end.getTime() - start.getTime();
            diffInSeconds = diffInMillis / 1000;

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return diffInSeconds;
    }

    /**
     * 计算百分比
     *
     * @param numerator   分子
     * @param denominator 分母
     * @return 百分数
     */
    public static String percentageCalculator(int numerator, int denominator) {
        // 计算百分比
        double percentage = ((double) numerator / denominator) * 100;
        // 格式化输出百分比为两位小数
        java.text.DecimalFormat df = new java.text.DecimalFormat("#.##");
        String formattedPercentage = df.format(percentage);
        return (formattedPercentage + "%");
    }

    private static int countPass(List<ResultData> resultDataList) {
        int count = 0;
        for (ResultData resultData : resultDataList) {
            if (RESULT_PASS.equals(resultData.getResult())) {
                count++;
            }
        }
        return count;
    }

    private static int countFail(List<ResultData> resultDataList) {
        int count = 0;
        for (ResultData resultData : resultDataList) {
            if (RESULT_FAIL.equals(resultData.getResult())) {
                count++;
            }
        }
        return count;
    }

    private static int countAbandon(List<ResultData> resultDataList) {
        int count = 0;
        for (ResultData resultData : resultDataList) {
            if (RESULT_ABANDON.equals(resultData.getResult()) || RESULT_DEVICE_UNSUPPORTED.equals(resultData.getResult())) {
                count++;
            }
        }
        return count;
    }

    public static String formatTotalTime(long totalTime) {
        long hours = totalTime / 3600;
        long remainingSeconds = totalTime % 3600;
        long minutes = remainingSeconds / 60;
        long seconds = remainingSeconds % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

}
